package multithreading.common;

/**
 * For whom is synchronized applicable in Java?
 * 1. Methods and Classes
 * 2. Variables and Classes
 * 3. Variables and Methods
 * *4. Methods and Blocks
 *
 */
class Q5 {

}
