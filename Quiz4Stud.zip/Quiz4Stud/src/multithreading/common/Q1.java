package multithreading.common;
//
///**
// * How would you properly create and start a thread?
// * 1. MyThread q1 = new MyThread(); 	q1.start();
// * 2. MyThread q1 = new MyThread("q1"); q1.start();
// * 3. MyThread q1 = new MyThread(); 	q1.run();
// * 4. MyThread q1 = new MyThread("q1"); q1.run();
// *
// */


//class MyThread extends Thread {
//	
//	public void run() {
//		System.out.println("Thread is running...");
//	}
//	
//}

class Q1 {
	public static void main(String args[]) {
		/* Your code here */
	}
}
