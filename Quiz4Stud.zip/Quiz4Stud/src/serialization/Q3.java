package serialization;

/**
 * Static class parameters are serialised.
 * 1. true
 * *2. false
 */
class Q3 {

}
