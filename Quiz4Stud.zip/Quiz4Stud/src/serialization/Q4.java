package serialization;

/**
 * What exception is thrown if serialVersionUID values do not match upon deserialization?
 * 1. NotSerializableException
 * 2. InvalidSerialException
 * 3. InvalidObjectException
 * *4. InvalidClassException
 */
class Q4 {

}
