package serialization;

/**
 * How would you inherit Serializable for class Product?
 * @author andreeamaria
 *
 * 1. class Product extends Serializable
 * 2. class Product extend Serializable
 * 3. class Product implement Serializable
 * *4. class Product implements Serializable
 */
class Q5 {

}
