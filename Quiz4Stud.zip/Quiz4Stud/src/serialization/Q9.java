package serialization;

/**
 * What class is used to read a sequence of bytes into a buffer from a stream?
 * 1. FileInputStream
 * 2. FileOutputStream
 * 3. BufferedOutputStream
 * *4. BufferedInputStream
 *
 */
public class Q9 {

}
