package serialization;

/**
 * What method is used to notify that a file is no longer needed?
 * *1. close()
 * 2. available()
 * 3. read()
 * 4. wait()
 *
 */
class Q7 {

}
