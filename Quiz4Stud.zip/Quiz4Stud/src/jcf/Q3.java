package jcf;

/**
 * TreeSet maintains an order of elements?
 * 1. No
 * *2. Yes, ascending order
 * 3. Yes, descending order
 * 4. Other
 */
public class Q3 {

}
