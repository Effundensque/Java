package java8;

/**
 * What is a functional interface?
 * 1. An interface that contains many abstract methods.
 * *2. An interface that contains a single abstract method.
 * 3. An interface that contains only implemented methods.
 * 4. None.
 */
class Q3 {

}