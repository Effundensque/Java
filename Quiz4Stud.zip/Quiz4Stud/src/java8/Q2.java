package java8;

class Q2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	}

}


/**
 * Which lambda statement is syntactically valid?
 *
 *	1. el -> {return el > 30;}
 *	2. (int el) -> {return el > 30;}
 *	3. el -> el > 30
 *	*4. all are valid
 */
