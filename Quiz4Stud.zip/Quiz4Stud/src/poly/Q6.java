package poly;

import java.io.Serializable;

/**
 * A class can implement many interfaces but extend only one class.
 * *1. True
 * 2. False
 *
 */
public class Q6 extends Object implements Serializable, AutoCloseable {

	@Override
	public void close() throws Exception {
		
	}

}
