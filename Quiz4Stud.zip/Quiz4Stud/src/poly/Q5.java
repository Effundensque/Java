package poly;

/**
 * What keyword is used to inherit a class?
 *	1. extend
 *	2. super
 *	3. this
 *	*4. extends
 */
public class Q5 extends Object{

}
