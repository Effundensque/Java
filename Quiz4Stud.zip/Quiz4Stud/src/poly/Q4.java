package poly;

/**
 * What is the process of defining a method in a subclass having same name and type signature as in its superclass?
 * *1. Method overriding
 * 2. Method hiding
 * 3. Method loading
 * 4. Method overloading
 *
 */
public class Q4 {

}
