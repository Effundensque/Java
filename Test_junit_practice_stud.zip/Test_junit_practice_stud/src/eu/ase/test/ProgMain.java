package eu.ase.test;

// This is the Java code playground

public class ProgMain {

	public static void main(String[] args) {
	    
	}

}
